MUSCLE PHARMA - BILINGUAL STORE
Open this folder in VS Code and run index.html with Live Server.
Use EN / عربي in the header to switch languages.
Cart supports quantity increase/decrease and item removal.
IMPORTANT: Edit script.js and WhatsApp checkout is configured for 201558318802 (Egypt international format). Egypt format: 201XXXXXXXXX.
Checkout opens WhatsApp with all selected products and quantities in the message.
Prices are currently price-on-request; add confirmed prices before publishing.
